<?php
/**
 * File field template.
 * 
 * @package Wp Travel Engine
 */
class WP_Travel_Engine_Form_Field_File extends WP_Travel_Engine_Form_Field_Text {
    
    // Defind field type.
    protected $field_type = 'file';

}
