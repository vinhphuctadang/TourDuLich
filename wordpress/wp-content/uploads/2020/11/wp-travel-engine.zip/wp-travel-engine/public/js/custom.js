jQuery(document).ready(function($){
   $('.wp-travel-engine-datetime').datepicker({ maxDate: 0, changeMonth: true,
		changeYear: true, dateFormat: 'yy-mm-dd', yearRange: "-100:+0" });

 //   $(".wp-travel-engine-price-datetime").datepicker({
 //        dateFormat: "yy-mm-dd",
 //        minDate: 0,
 //        changeMonth: true,
	// 	changeYear: false,
 //        onSelect: function(){
 //            $(".check-availability").hide();
 //            $(".book-submit").fadeIn("slow");
 //        }
	// });
   
});